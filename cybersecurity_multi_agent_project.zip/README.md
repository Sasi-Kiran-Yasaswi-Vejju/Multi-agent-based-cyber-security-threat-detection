# Multi-Agent AI-Based Cybersecurity Threat Detection and Response System

**Course**: 23CSE401 – Foundations of Artificial Intelligence  
**Evaluation**: Review 1 (10 Marks Evaluation Rubric)  

### Team Members
* **Member 1**: Nanthakumaran (`CB.SC.U4CSE23341`) — Data Perception & Agent 1 (Intrusion Detection)
* **Member 2**: Dhinesh chandra (`CB.SC.U4CSE23310`) — Knowledge Representation & Agent 2 (Threat Analysis)
* **Member 3**: Vejju Sasi Kiran Yasaswi (`CB.SC.U4CSE23356`) — Algorithmic Modeling, Search (BFS/A*) & Integration

---

## 1. Review 1 Evaluation Rubric Alignment (10 Marks)

| Evaluation Component | Marks | Direct Implementation Evidence | Status |
| :--- | :---: | :--- | :---: |
| **PEAS Formulation** | **3 Marks** | Formal PEAS tables for Agent 1 and Agent 2 with measurable KPIs (Section 3). | Complete |
| **Environment & Agent Analysis** | **3 Marks** | 7-dimension Russell & Norvig environment taxonomy + agent autonomy & rationality (Section 4). | Complete |
| **Algorithmic Modeling & Search** | **3 Marks** | $\langle S_0, S, A, T, G, c \rangle$ formalization, BFS vs A* implementations, $g(n)$ cost model, admissible $h(n)$ proof (Section 5). | Complete |
| **Q&A & Presentation Mechanics** | **1 Mark** | 12-slide presentation structure, student speaking distribution, and faculty Q&A crib sheet (Section 8). | Complete |
| **Total** | **10 / 10** | **Rigorous academic defense supported by live reproducible code.** | **Target: 10/10** |

---

## 2. Strong Multi-Agent Justification: Why Multiple Agents?

A common failure mode in academic projects is building a single monolithic script and labeling it an "agent." In cybersecurity, **perception** and **deliberation/planning** represent fundamentally distinct AI paradigms that cannot be unified into a single monolithic model without degrading performance:

```
                      INCOMING NETWORK EVENT
                                ↓
        ┌───────────────────────────────────────────────┐
        │       AGENT 1: INTRUSION DETECTION AGENT      │
        │ • Perception & Statistical Machine Learning    │
        │ • Answers: "Is this activity normal or       │
        │   malicious, with what confidence?"           │
        └───────────────────────┬───────────────────────┘
                                │ Structured JSON Wire Message
                                │ (Agent1Message)
                                ↓
        ┌───────────────────────────────────────────────┐
        │   AGENT 2: THREAT ANALYSIS & RESPONSE AGENT   │
        │ • Knowledge Reasoning & State-Space Search    │
        │ • Answers: "What does this threat mean, and   │
        │   what is the cost-optimal defensive action?" │
        └───────────────────────┬───────────────────────┘
                                ↓
                     OPTIMAL MITIGATION DISPATCH
```

### Why Combining Them into One Monolithic Agent Fails:
1. **Separation of Concerns**: Agent 1 handles high-throughput, low-latency perceptual classification over continuous numerical features. Agent 2 handles deliberative discrete state-space search over symbolic goals and operational costs.
2. **Modularity & Extensibility**: In Review 2, new specialized agents (e.g., Threat Intelligence Agent, Dynamic Risk Assessment Agent) can be inserted into the message chain without modifying Agent 1 or Agent 2.
3. **Independent Validation**: Agent 1 is evaluated using statistical metrics (Confusion Matrix, Precision, Recall, F1). Agent 2 is evaluated using algorithmic search metrics (Path Cost, Node Expansions, Admissibility). Combining them obscures where an error originated.
4. **Explainability & Security Auditing**: Enterprise security operations require clear provenance. If an IP is blocked, auditors can trace: *Agent 1 classified anomaly with 91.6% confidence -> Agent 2 applied CIA Triad rule base -> A\* proved that source blocking incurred lower operational disruption (cost 10) than server isolation (cost 14)*.

---

## 3. PEAS Formulations (3 Marks)

### Agent 1: Intrusion Detection Agent (Perception & Classification)

| PEAS Element | Technical Specification |
| :--- | :--- |
| **Performance Measure (P)** | • **Recall / Sensitivity** $\ge 74\%$ (Minimizing missed breaches/False Negatives).<br>• **Precision** $\approx 100\%$ (Minimizing false alarms and SOC alert fatigue).<br>• **F1-Score** $\ge 85\%$.<br>• **Inference Latency** $\le 5$ ms per session.<br>• **Explainability**: Generates forensic indicator evidence strings. |
| **Environment (E)** | • Inbound network connection flows, transport packet headers, authentication velocity counters, session duration metrics. |
| **Actuators (A)** | • Emits validated alerts.<br>• Compiles and transmits structured `Agent1Message` over JSON channel.<br>*(Deliberately no raw socket/packet dropping to maintain separation of concerns).* |
| **Sensors (S)** | • Session feature parsers: `network_packet_size`, `protocol_type`, `login_attempts`, `session_duration`, `ip_reputation_score`, `failed_logins`, `encryption_used`, `browser_type`, `unusual_time_access`. |

### Agent 2: Threat Analysis & Response Planning Agent (Reasoning & Search)

| PEAS Element | Technical Specification |
| :--- | :--- |
| **Performance Measure (P)** | • **Threat Neutralization**: Successfully reaching goal state `INCIDENT_CONTROLLED`.<br>• **Cost Optimality**: Finding the path that minimizes total operational disruption $g(n)$.<br>• **Search Efficiency**: Node expansion count and planning latency $\le 2$ ms.<br>• **Risk Reduction**: Measurable reduction of composite risk score $\le 10$. |
| **Environment (E)** | • Incoming inter-agent JSON message queue, declarative cybersecurity knowledge base (`knowledge/cybersecurity_rules.json`), enterprise asset criticality catalog, response state-space graph. |
| **Actuators (A)** | • Mitigation policy dispatch: `MONITOR`, `VERIFY`, `BLOCK_SOURCE`, `ISOLATE_HOST`, `ESCALATE`.<br>• Production of formal `Agent2Response` audit log. |
| **Sensors (S)** | • JSON wire message receiver ingesting `Agent1Message`.<br>• Rule-base inference query engine.<br>• State-space graph explorer. |

---

## 4. Environment & Agent Analysis (3 Marks)

### 7-Dimension Environment Classification (Russell & Norvig Standards)

| Property | Classification | Academic Justification |
| :--- | :--- | :--- |
| **Observability** | **Partially Observable** | The agents only observe extracted session flow statistics and connection metadata. The adversary's internal intent, payload encryption internals, and external command-and-control servers remain unobservable. |
| **Determinism** | **Stochastic** | The environment is non-deterministic. Identical telemetry may occasionally arise from legitimate unusual activity or malicious zero-day exploits. Defensive actions (e.g. blocking an IP) carry uncertain operational side effects (e.g. disrupting shared proxy users). |
| **Dynamics** | **Dynamic** | Network traffic streams continuously and the threat landscape changes while agents perform classification and search planning. The environment does not pause during agent computation. |
| **Episodic / Sequential** | **Agent 1: Episodic<br>System: Sequential** | • Agent 1's classification is **episodic**: whether session $k$ is malicious is independent of session $k-1$.<br>• The end-to-end multi-agent workflow is **sequential**: current detection influences threat analysis, which triggers response planning, which fundamentally alters subsequent enterprise security state. |
| **Discrete / Continuous** | **Mixed** | Continuous numerical features (`session_duration`, `ip_reputation_score`, `confidence` $\in [0, 1]$) coexist with discrete nominal protocols (`TCP`, `UDP`), discrete attack categories, and discrete response graph nodes. |
| **Number of Agents** | **Multi-Agent** | Exactly two collaborating autonomous agents in Phase 1 (scalable to 4 in Phase 2). |
| **Agent Interaction** | **Cooperative** | The agents share a common global objective function: preserving organizational security (Confidentiality, Integrity, Availability) without competing utility functions. |

### Agent Behavioral Dimensions
* **Autonomy**: Agents make decisions based on internal learned models and declarative knowledge rules without requiring continuous human intervention.
* **Rationality**: Agent 1 maximizes posterior classification accuracy; Agent 2 executes A* search to guarantee minimum expected operational disruption cost.
* **Reactivity**: Agents respond rapidly to perceptual triggers (traffic bursts and security alerts).
* **Goal-Directed Behavior**: Agent 2 does not rely on static hard-coded reactions; it evaluates a formal goal (`INCIDENT_CONTROLLED`) and searches through candidate action paths.

---

## 5. Algorithmic Modeling & Search Strategy (3 Marks)

### Formal State-Space Problem Formulation: $\langle S_0, S, A, T, G, c \rangle$

1. **State Space ($S$)**:
   Each state $s$ represents the current defensive posture:
   - `ATTACK_DETECTED` (Initial Start State $S_0$)
   - `PASSIVE_TRACKING` (Low-severity monitoring state)
   - `THREAT_CONFIRMED` (Verified malicious session)
   - `SOURCE_BLOCKED` (Firewall packet drop active)
   - `HOST_ISOLATED` (Quarantined endpoint)
   - `SOC_ALERTED` (Escalated to human analysts)
   - `INCIDENT_CONTROLLED` (Goal State $G$)
2. **Action Set ($A$) and Operational Cost Function $c(u, v)$**:
   Operational costs reflect real-world enterprise disruption and engineering overhead:
   * `MONITOR` ($c = 1.0$): Zero disruption; passive logging telemetry.
   * `VERIFY_MITIGATION` ($c = 2.0$): Automated ping/health-check probe.
   * `VERIFY` ($c = 3.0$): Low user friction; challenge-response / secondary auth.
   * `MANUAL_OVERRIDE` ($c = 4.0$): Human SOC analyst triage time.
   * `BLOCK_SOURCE` ($c = 5.0$): Moderate disruption; potential shared proxy collateral.
   * `ESCALATE` ($c = 8.0$): High cost; paging on-call incident response engineers.
   * `ISOLATE_HOST` ($c = 10.0$ to $14.0$): Severe impact; complete service downtime.
3. **Transition Model ($T$)**:
   * `ATTACK_DETECTED` --(`VERIFY`, $c=3$)-> `THREAT_CONFIRMED`
   * `ATTACK_DETECTED` --(`MONITOR`, $c=1$)-> `PASSIVE_TRACKING`
   * `ATTACK_DETECTED` --(`ESCALATE`, $c=8$)-> `SOC_ALERTED`
   * `THREAT_CONFIRMED` --(`BLOCK_SOURCE`, $c=5$)-> `SOURCE_BLOCKED`
   * `THREAT_CONFIRMED` --(`ISOLATE_HOST`, $c=10$)-> `HOST_ISOLATED`
   * `SOURCE_BLOCKED` --(`VERIFY_MITIGATION`, $c=2$)-> `INCIDENT_CONTROLLED`
   * `HOST_ISOLATED` --(`VERIFY_MITIGATION`, $c=2$)-> `INCIDENT_CONTROLLED`
   * `SOC_ALERTED` --(`MANUAL_OVERRIDE`, $c=4$)-> `INCIDENT_CONTROLLED`

### A* Evaluation Function: $f(n) = g(n) + h(n)$
* **$g(n)$**: Accumulated path cost incurred from $S_0$ to node $n$.
* **$h(n)$**: Estimated remaining cost to reach `INCIDENT_CONTROLLED`.
* **Admissibility Proof ($h(n) \le h^*(n)$)**:
  For every state $n$, $h(n)$ never overestimates the true remaining cost $h^*(n)$:
  - `ATTACK_DETECTED`: $h(n) = 8.0 \le h^*(n) = 10.0$ (`VERIFY` (3) + `BLOCK` (5) + `VERIFY_MIT` (2) = 10)
  - `THREAT_CONFIRMED`: $h(n) = 7.0 \le h^*(n) = 7.0$ (`BLOCK` (5) + `VERIFY_MIT` (2) = 7)
  - `SOURCE_BLOCKED`: $h(n) = 2.0 \le h^*(n) = 2.0$
  - `HOST_ISOLATED`: $h(n) = 2.0 \le h^*(n) = 2.0$
  - `SOC_ALERTED`: $h(n) = 4.0 \le h^*(n) = 4.0$
  - `INCIDENT_CONTROLLED`: $h(n) = 0.0 \le h^*(n) = 0.0$
* **Consistency Proof ($h(u) \le c(u, a, v) + h(v)$)**:
  Satisfies the triangle inequality across all edges (verified programmatically via automated unit test `test_heuristic_consistency_triangle_inequality`).

---

## 6. Experimental Results & Benchmarks

### Supervised Classification Benchmark (Agent 1)
* **Dataset**: 9,537 authentic connection sessions (Stratified 80/20 train/test split: 7,629 train, 1,908 test).
* **Class Distribution**: 55.3% Normal (1,055 test), 44.7% Attack (853 test).

| Metric | Random Forest (Primary) | Decision Tree (Baseline) | Operational Security Significance |
| :--- | :---: | :---: | :--- |
| **Accuracy** | **88.63%** | 88.42% | Baseline correctness over balanced test set. |
| **Precision (Attack)** | **100.00%** | 100.00% | **Zero False Positives**: Prevents SOC alert fatigue. |
| **Recall (Attack)** | **74.56%** | 74.09% | Catches 3 out of every 4 malicious intrusion attempts. |
| **F1-Score** | **85.43%** | 85.12% | Harmonic balance between Precision and Recall. |
| **False Positive Rate** | **0.00%** | 0.00% | No benign users are erroneously blocked. |
| **False Negative Rate** | **25.44%** | 25.91% | Residual risk escalated to secondary heuristics. |

> **Why Accuracy Alone Fails**: In enterprise networks with 99.9% benign traffic, a trivial model predicting "NORMAL" achieves 99.9% accuracy while letting 100% of cyberattacks succeed. High Precision and Recall on the Attack class provide the true academic metric of defensive utility.

### Search Strategy Comparison: BFS vs. A* (Agent 2)

| Metric | BFS (Uninformed) | A* (Informed) | Academic Finding |
| :--- | :---: | :---: | :--- |
| **Search Type** | Uninformed FIFO Queue | Informed Priority Queue $f = g + h$ | A* leverages domain knowledge. |
| **Path Hop Count** | **2 hops** | 3 hops | BFS prioritizes shallowest hop count. |
| **Total Path Cost** | **12.0** | **10.0** | **A\* achieves 16.7% operational cost savings.** |
| **Nodes Explored** | 8 nodes | 4 nodes | A* explores 50% fewer states. |
| **Execution Time** | 0.0037 ms | 0.0060 ms | BFS has slightly lower raw queue overhead. |
| **Optimality Guarantee** | Sub-optimal for weighted costs | **Provably Cost-Optimal** | **A\* guarantees minimum disruption.** |

* **BFS Path**: `ATTACK_DETECTED` --(`ESCALATE`, 8)--> `SOC_ALERTED` --(`MANUAL`, 4)--> `INCIDENT_CONTROLLED` (Cost: 12.0)
* **A\* Path**: `ATTACK_DETECTED` --(`VERIFY`, 3)--> `THREAT_CONFIRMED` --(`BLOCK`, 5)--> `SOURCE_BLOCKED` --(`VERIFY_MIT`, 2)--> `INCIDENT_CONTROLLED` (Cost: 10.0)

---

## 7. How to Run & Verify

### Step 1: Clone / Enter Directory
```bash
cd "c:/Users/sasik/Downloads/FOAI/Case Study/cybersecurity_multi_agent"
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Run Model Training & Evaluation
```bash
python train_model.py
```
*(Preprocesses 9,537 records, trains Random Forest & Decision Tree, outputs confusion matrix, and serializes artifacts to `models/`).*

### Step 4: Run Automated Unit & Integration Tests
```bash
python -m unittest discover -s tests -v
```
*(Executes 15 unit tests covering Agent 1 perception, Agent 2 reasoning, search admissibility, and multi-agent integration).*

### Step 5: Run Live Interactive Demonstration
```bash
python run_system.py --demo
```

### Step 6: Run 1,000-Iteration Search Benchmark
```bash
python run_system.py --benchmark
```

---

## 8. Review 1 Presentation Structure & Speaking Roles (12 Slides)

* **Slide 1: Title & Team Introduction** — *Speaker: All 3 Members*
  * Project Title, Course 23CSE401, Team Members & IDs.
* **Slide 2: Problem Statement & Motivation** — *Speaker: Nanthakumaran*
  * Vulnerabilities of single-agent monolithic architectures in cybersecurity.
* **Slide 3: Project Objectives & Review 1 Milestones** — *Speaker: Nanthakumaran*
  * 10-Mark Rubric alignment: PEAS, Environment, State-Space Search, Agent Communication.
* **Slide 4: Why Multi-Agent AI?** — *Speaker: Dhinesh chandra*
  * Perception (Agent 1) vs. Deliberation/Search Planning (Agent 2) decomposition.
* **Slide 5: System Architecture & Data Flow** — *Speaker: Vejju Sasi Kiran Yasaswi*
  * Loose coupling via structured JSON message passing (`Agent1Message` -> `Agent2Response`).
* **Slide 6: PEAS Formulation for Agent 1** — *Speaker: Nanthakumaran*
  * Performance measures, sensors, actuators, network environment.
* **Slide 7: PEAS Formulation for Agent 2** — *Speaker: Dhinesh chandra*
  * Knowledge-base reasoning, risk score, mitigation actuators.
* **Slide 8: Environment & Agent Analysis** — *Speaker: Dhinesh chandra*
  * 7-dimension classification (Partially Observable, Stochastic, Dynamic, Mixed, Cooperative).
* **Slide 9: Algorithmic Modeling: State-Space Formulation** — *Speaker: Vejju Sasi Kiran Yasaswi*
  * Formal $\langle S_0, S, A, T, G, c \rangle$ response graph definition.
* **Slide 10: Search Strategy: BFS vs. A\*** — *Speaker: Vejju Sasi Kiran Yasaswi*
  * Uninformed vs. Informed search, $f(n) = g(n) + h(n)$, admissibility proof ($h(n) \le h^*(n)$).
* **Slide 11: Quantitative Results & Search Benchmarks** — *Speaker: Vejju Sasi Kiran Yasaswi*
  * Random Forest 88.6% accuracy, 100% precision; A* 16.7% cost reduction vs. BFS.
* **Slide 12: Live Demonstration & Phase 2 Expansion** — *Speaker: All 3 Members*
  * Live CLI execution, Threat Intelligence & Risk Assessment Agent roadmap.

---

## 9. Faculty Q&A Crib Sheet

**Q1: Why did you use two agents instead of one unified Python script?**  
*Answer*: Intrusion detection is a high-speed *data-driven perception problem* over continuous numeric flow features. Threat mitigation is a *discrete knowledge-based planning problem* over symbolic actions and business operational costs. Coupling them into a monolith degrades modularity, prevents independent model upgrades, and eliminates explainability.

**Q2: Why is accuracy alone insufficient for evaluating cybersecurity AI?**  
*Answer*: In real enterprise networks, benign traffic vastly outnumbers malicious traffic (e.g. 99% normal). A naive classifier that predicts "NORMAL" for every packet achieves 99% accuracy but allows 100% of cyberattacks to succeed (the Base Rate Fallacy). In cybersecurity, Precision, Recall, and False Positive Rate are the critical operational metrics.

**Q3: Why did BFS produce a higher cost path than A\*?**  
*Answer*: BFS is an uninformed search algorithm that expands states layer-by-layer, assuming all edge transitions have uniform cost ($c=1$). Consequently, BFS finds the path with the *fewest number of hops* (2 hops: `ATTACK` -> `ESCALATE` -> `CONTROLLED`, cost 12.0). In contrast, A* uses $f(n) = g(n) + h(n)$ to evaluate real-world operational disruption costs, discovering that a 3-hop path (`ATTACK` -> `VERIFY` -> `BLOCK` -> `CONTROLLED`) incurs a lower total cost (10.0).

**Q4: How do you prove that your heuristic $h(n)$ is admissible?**  
*Answer*: A heuristic is admissible if $h(n) \le h^*(n)$ for all states $n$, where $h^*(n)$ is the true minimum cost to the goal. In our response graph, for every single state, our heuristic under-estimates or equals the true cost (e.g., at `ATTACK_DETECTED`, $h=8.0$ while $h^*=10.0$; at goal, $h=0$). We verify this mathematically and enforce it through an automated unit test.

**Q5: How do the two agents communicate?**  
*Answer*: Agents communicate exclusively through strongly-typed, schema-validated JSON wire messages (`Agent1Message`). Agent 2 has zero access to Agent 1's internal memory pointers, trained weights, or variables.
